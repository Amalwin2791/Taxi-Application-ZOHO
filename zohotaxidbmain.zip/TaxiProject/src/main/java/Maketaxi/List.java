package Maketaxi;
import java.sql.SQLException;
import java.util.*;
public class List {
	 public static ArrayList<Taxi> taxis = new ArrayList<Taxi>();
	public static void createTaxis() throws ClassNotFoundException, SQLException
    {
         for(int i=1 ;i <=5;i++)
        {
        	Taxi t = new Taxi(i);
            taxis.add(t);
        }
        }
        
    }


