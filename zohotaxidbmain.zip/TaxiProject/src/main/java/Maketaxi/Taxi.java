package Maketaxi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mysql.jdbc.Statement;

import Taxi.DatabaseConnection;

public class Taxi {
	static int taxicount = 0;
    public int id;
    public boolean booked;
    public char currentSpot;
    public double freeTime;
    public int totalEarnings;
    public double pickupTime;
    public double dropTime;
    public char dropPoint;
    public char pickupPoint;
    public int taxiId;
    
    List<String> trips;
    static HashMap<String, String> map = new HashMap<String, String>();


    public Taxi(int i) throws ClassNotFoundException, SQLException
    {
    	String dbDriver = "com.mysql.jdbc.Driver";
    	String dbURL = "jdbc:mysql://127.0.0.1:3306/Taxi?autoReconnect=true&useSSL=false";

    	// Database name to access
    	//String dbName = "Taxi";
    	String dbUsername = "root";
    	String dbPassword = "amal";

    	Class.forName(dbDriver);

    	//Connection connection = null;
    	java.sql.Statement statement = null;
    	ResultSet resultSet = null;
    	Connection con = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
    	statement = con.createStatement();
		String sql = "select * from taxidetails where TaxiID ="+i;
		
		resultSet = statement.executeQuery(sql);
		resultSet.next();
		
		booked = false;
        currentSpot = resultSet.getString("CurrentLocation").charAt(0);
        System.out.println(currentSpot);
        freeTime = 0;
        totalEarnings = resultSet.getInt("TotalEarnings");
        trips = new ArrayList<String>();
        taxicount = taxicount + 1;
        id = taxicount;
    }
    public void setDetails(char currentSpot,double freeTime,int totalEarnings,String tripDetail,double pickupTime, char pickupPoint,int bookedTaxi) throws ClassNotFoundException, SQLException
    {

        this.currentSpot = currentSpot;
        this.freeTime = freeTime;
        this.totalEarnings = totalEarnings;
        this.trips.add(tripDetail);
        this.pickupTime = pickupTime;
        this.dropTime = freeTime;
        this.pickupPoint = pickupPoint;
        this.taxiId=bookedTaxi ;
        this.dropPoint= currentSpot;
        
        
        
    }

    public void printDetails()
    {

        System.out.println("Taxi - "+ this.id + " Total Earnings - " + this.totalEarnings);
        System.out.println("TaxiID    BookingID    CustomerID    From    To    PickupTime    DropTime    Amount");
        for(String trip : trips)
        {
            System.out.println(id + "          " + trip);
        }
    }

}
