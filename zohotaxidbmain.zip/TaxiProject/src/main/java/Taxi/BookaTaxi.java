package Taxi;
import java.util.*;

import Taxi.freeList;
import Taxi.DatabaseConnection;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Maketaxi.List;
import Maketaxi.Taxi;
@WebServlet("/BookaTaxi")
/**
 * Servlet implementation class BookaTaxi
 */
public class BookaTaxi extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static HashMap< Character,String> map = new HashMap< Character,String>();      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookaTaxi() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("customerid"));
        char pickupPoint=(request.getParameter("pickup")).charAt(0);
        char dropPoint=(request.getParameter("drop")).charAt(0);
        double pickupTime=Double.parseDouble(request.getParameter("picktime"));
        String pickuptime2[] = request.getParameter("picktime").split("[.]");
        int hours = Integer.parseInt(pickuptime2[0]);
        int minutes = Integer.parseInt(pickuptime2[1]);
        
        
        
        try {
			Connection con = DatabaseConnection.initializeDatabase();
			PreparedStatement st = con.prepareStatement("insert into taxi values(?,?,?,?,?,?,?)");
			PreparedStatement pt = con.prepareStatement("update taxidetails set CurrentLocation=?, TotalEarnings = ? where TaxiID = ? ");
			List.createTaxis();
			map.put( 'A',"DLF");
			map.put( 'B',"Velachery");
			map.put( 'C',"Tambaram");
			map.put( 'D',"Tnagar");
			map.put( 'E',"Nungambakkam");
			int min = 999;
	        int distanceBetweenpickUpandDrop = 0;
	        int earning = 0;
	        double nextfreeTime = 0;
	        char nextSpot = 'Z' ;
	        Taxi bookedTaxi = null;
	        String tripDetail = "";
	        
	        st.setInt(2, id);
	        st.setString(3, String.valueOf(pickupPoint));
	        st.setString(4, String.valueOf(dropPoint));
	        st.setDouble(5, pickupTime);
	        
	        
	        
	        
	        pt.setString(1, String.valueOf(dropPoint));
	        
	        
	        //pt.setString(2, String.valueOf(dropPoint));
	        ArrayList<Taxi> freeTaxis = freeList.getFreeTaxis(List.taxis,pickupTime,pickupPoint);
	        
	        for(Taxi t : freeTaxis)
	        {
	            int distanceBetweenCustomerAndTaxi = (Math.abs((t.currentSpot - '0') - (pickupPoint - '0'))) * 15;
	            if(distanceBetweenCustomerAndTaxi < min)
	            {

	                bookedTaxi = t;
	                distanceBetweenpickUpandDrop = Math.abs((dropPoint - '0') - (pickupPoint - '0')) * 15;
	                if(pickupPoint == t.currentSpot){
	                    earning = (distanceBetweenpickUpandDrop) * 10 ;
	                }
	                else {
	                    int distanceBetweenPickupAndCurrent = distanceBetweenCustomerAndTaxi * 5;
	                    earning = ((distanceBetweenpickUpandDrop) * 10) - distanceBetweenPickupAndCurrent;
	                }
	                double dropTime  = pickupTime + (distanceBetweenpickUpandDrop/15)*0.15;
	                System.out.println(dropTime);
	                int tminutes= distanceBetweenpickUpandDrop;
	    	        int z = minutes + tminutes;
	    	        hours += z/60;
	    	        hours %= 24;
	    	        minutes = z%60;
	    	        String finalDropTime = hours+"."+minutes;
	    	        st.setString(6, finalDropTime);
	                nextfreeTime = dropTime;
	                nextSpot = dropPoint;
	               
	                tripDetail = id + "               " + id + "          " + pickupPoint +  "      " + dropPoint + "       " + pickupTime + "          " +dropTime + "           " + earning;
	                min = distanceBetweenCustomerAndTaxi;
	                st.setInt(1, bookedTaxi.id);
	                
	                st.setInt(7, earning);
	                
	                
	                pt.setInt(3, bookedTaxi.id);
	                
	                
	                
	            }
	        }
	        bookedTaxi.setDetails(nextSpot,nextfreeTime,bookedTaxi.totalEarnings + earning,tripDetail, pickupTime,  pickupPoint,bookedTaxi.id );
	        
	        pt.setInt(2, bookedTaxi.totalEarnings );
	        
	        java.io.PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE html>");
	        out.println("<html>");
	        out.println("<head>");
	        
	        out.println("<title align = \"center\">TAXI BOOKED</title>");
	        out.println("<body bgcolor = \"violet\">");
	        out.println("<div align=\"center\">");
			out.println("<h1>Customer id: " + id + "</h1>");
			out.println("<h1>Taxi id: " + bookedTaxi.id + "</h1>");
			out.println("</div>");
			out.println("</body>");
	        out.println("</head>");
	        out.println("</html>");
	        
	        st.executeUpdate();
	        
            
            pt.executeUpdate();
	        pt.close();
	        st.close();
	        
	        
	        
	        con.close();
	        
		}catch (Exception e){
			
	            e.printStackTrace();
	            
	}
	}
}
