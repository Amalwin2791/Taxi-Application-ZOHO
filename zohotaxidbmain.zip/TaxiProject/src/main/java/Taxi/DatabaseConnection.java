package Taxi;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;


public class DatabaseConnection {
	public static Connection initializeDatabase()
		throws SQLException, ClassNotFoundException
	{
		
		String dbDriver = "com.mysql.jdbc.Driver";
		String dbURL = "jdbc:mysql://127.0.0.1:3306/Taxi?autoReconnect=true&useSSL=false";
		
		String dbUsername = "root";
		String dbPassword = "amal";

		Class.forName(dbDriver);
		Connection con = DriverManager.getConnection(dbURL ,
													dbUsername,
													dbPassword);
		
		return con;
		
	}
	 public void freeConnection(Connection con) {
	        try {
	            con.close();
	        } catch (SQLException e) {
	            System.out.println(e);
	        }
	    }
}

