package Taxi;

import Maketaxi.Taxi;




import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Maketaxi.List;
import Maketaxi.Taxi;
@WebServlet("/RestMode")
/**
 * Servlet implementation class Restmode
 */
public class Restmode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Restmode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("taxid"));
		int restChoice=Integer.parseInt(request.getParameter("restchoice"));
		
		// TODO Auto-generated method stub
		if (restChoice==1){
            Taxi obj= List.taxis.get(id-1);
            obj.booked=true;
            java.io.PrintWriter out = response.getWriter();
    		out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>TAXI inactive </title>");
            out.println("<body bgcolor = \"orange\">");
            out.println("<div align=\"center\">");
    		out.println("<h1>Taxi id: " + id + " is inactive now</h1>");
    		out.println("</div>");
    		out.println("</body>");
            out.println("</head>");
            out.println("</html>");
            System.out.println("Taxi "+ id + " is set at rest");
        }
        else if (restChoice ==2){

            Taxi obj= List.taxis.get(id-1);
            obj.booked=false;
            java.io.PrintWriter out = response.getWriter();
    		out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>TAXI active </title>");
            out.println("<body bgcolor = \"purple\">");
            out.println("<div align=\"center\">");
    		out.println("<h1>Taxi id: " + id + " is active now</h1>");
    		out.println("</div>");
    		out.println("</body>");
            out.println("</head>");
            out.println("</html>");
            System.out.println("Taxi "+ id + " is releived");
        }
		
		
	}

}
