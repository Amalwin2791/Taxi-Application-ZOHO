package Taxi;

import java.util.ArrayList;

import Maketaxi.Taxi;

public class freeList {
	public static ArrayList<Taxi> getFreeTaxis(ArrayList<Taxi> taxis,double pickupTime,char pickupPoint)
    {
        ArrayList<Taxi> freeTaxis = new ArrayList<Taxi>();
        for(Taxi t : taxis)
        {
            if(t.freeTime <= pickupTime && t.booked == false)
                freeTaxis.add(t);
        }
        return freeTaxis;
    }

}
